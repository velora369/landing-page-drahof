// WhatsApp URL with the phone number mentioned in the requirements
export const WHATSAPP_URL = "https://wa.me/5565996955300";

// Address info
export const CLINIC_ADDRESS = "Rua Cardoso de Almeida, 313, Conjunto 51";
export const CLINIC_PHONE = "(65) 99695-5300";

// Colors
export const COLORS = {
  teal: "#425F70",
  burgundy: "#731C13",
  white: "#FFFFFF",
  cream: "#ECE0C4"
};

// Instagram handle
export const INSTAGRAM_HANDLE = "@drahof";
